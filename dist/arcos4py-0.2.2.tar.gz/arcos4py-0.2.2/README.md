Arcos-Py: Read Me

Howdy!